# ai-agent 项目全流程分析

## 一、项目定位

一个基于 **Spring AI + DashScope（通义千问）** 的多场景 AI 对话应用，包含恋爱心理咨询、足球数据分析两种场景，探索了多种 RAG（检索增强生成）、多轮对话、自定义 Advisor 等 Spring AI 核心能力。

**技术栈：** Spring Boot 3.4.4 + Spring AI 1.1.2 + Spring AI Alibaba 1.1.2.0

---

## 二、整体架构概览

```
项目 = 两个 AI 应用 + 公共基础设施
     ├── LoveApp           → 恋爱心理咨询场景
     ├── FootballAnalysisApp → 足球数据分析场景
     └── 公共层
          ├── Advisor 体系      → 请求拦截与增强
          ├── ChatMemory 体系   → 多轮对话持久化
          ├── RAG 体系         → 检索增强生成
          ├── Prompt 模板体系   → 提示词管理
          └── 基础调用 Demo     → 不同 SDK 的调用尝试
```

---

## 三、公共基础设施层

### 3.1 自定义 Advisor 体系

Advisor 是 Spring AI 的请求拦截机制（类似 Spring MVC 的 Interceptor），项目实现了 4 个：

| Advisor | 文件 | 作用 | 阶段 |
|---------|------|------|------|
| `ProfanityFilterAdvisor` | `advisor/ProfanityFilterAdvisor.java` | 违禁词检测，命中拦截并返回预设回复 | 调用前拦截 |
| `TimeAdvisor` | `advisor/TimeAdvisor.java` | 统计每次 LLM 调用的耗时 | 记录开始+结束时间 |
| `myLogAdvisor` | `advisor/myLogAdvisor.java` | 通用请求/响应日志记录 | 入参+出参都打印 |
| `Re2Advisor` | `advisor/Re2Advisor.java` | Re2（Read-then-Reason）：在用户问题后追加 "Read the question again" 提升模型推理质量 | Prompt 注入 |

使用方式：在 `ChatClient.Builder` 的 `.defaultAdvisors()` 中注册，或调用时 `.advisors()` 动态添加。

### 3.2 ChatMemory 多轮对话持久化体系

实现了 **三种** 对话历史持久化方案：

#### 方案 A：基于文件的 Kryo 序列化

```
FileBasedChatMemory (chatMemory/FileBasedChatMemory.java)
  实现 Spring AI 的 ChatMemory 接口
  使用 Kryo 将 List<Message> 序列化为 .kryo 文件
  按 conversationId 命名存储到 chat-memory/ 目录下
```

#### 方案 B：基于 MySQL 的持久化

```
MysqlBasedChatMemoryRepository (实现了 ChatMemoryRepository 接口)
  ├── saveAll()     : 先删后插，按 msg_index 排序
  ├── findByConversationId() : 按 conversationId 查询，通过转换器转 Message
  └── deleteByConversationId() : 按 conversationId 删除

ChatMessageConvertor (双向转换工具类)
  ├── toChatMessage()  : Message → ChatMessage (数据库实体)
  └── toMessage()      : ChatMessage → Message (Spring AI 消息)

ChatMessage (domain/ChatMessage.java)
  MyBatis-Plus 实体类，对应 chat_message 表
```

#### 方案 C：内存窗口

```
ChatMemoryConfig.java → MessageWindowChatMemory(maxMessages=10)
  只在内存中保留最近 10 条消息
```

### 3.3 RAG（检索增强生成）体系

#### 文档处理流水线

```
MarkdownDocumentLoader 加载 .md 文件
  │
  ▼
TokenTextSplitter 文本切分（可自定义 chunk 大小）
  │
  ▼
MetadataEnricher 元信息增强
  ├── KeywordMetadataEnricher  → 自动提取关键词
  └── SummaryMetadataEnricher  → LLM 生成摘要
  │
  ▼
EmbeddingModel 向量化
  │
  ▼
SimpleVectorStore 本地向量存储
```

#### 查询扩展（多查询展开）

```
MyMultiQueryExpander (实现了 QueryExpander 接口)
  内部封装 MultiQueryExpander
  numberOfQueries=3, includeOriginal=true
  将 1 个原始查询扩展为 4 个
```

#### 知识库检索 Advisor 方案

| 方案 | 文件 | 检索器 | 知识来源 |
|------|------|--------|---------|
| 本地 VectorStore | `LoveAppVectorStoreConfig.java` | `VectorStoreDocumentRetriever` | 本地 SimpleVectorStore |
| 云知识库（DashScope） | `LoveAppRagCloudAdvisorConfig.java` | `DashScopeDocumentRetriever` | DashScope 云端知识库 |
| 本地+多查询扩展 | `LoveAppRagConfig.java` | `VectorStoreDocumentRetriever` + `MultiQueryExpander` | 本地知识库 + 查询扩展 |
| 云知识库+多查询扩展 | `LoveAppRagCloudAdvisorConfig.java` | `DashScopeDocumentRetriever` + `MyMultiQueryExpander` | DashScope 云端 + 查询扩展 |

### 3.4 Prompt 模板体系

```
PromptTemplateService (prompt/PromptTemplateService.java)
  ├── 从 classpath:prompts/ 加载 .st 模板（StringTemplate 格式）
  ├── ConcurrentHashMap 缓存已加载模板
  ├── render() 做变量替换：{variableName} → value
  └── reloadTemplate() 强制重新加载（绕过缓存）

模板文件：src/main/resources/prompts/football-analysis.st
```

### 3.5 多种 AI 调用方式 Demo

项目还探索了多种调用 AI 大模型的途径：

| 调用方式 | 文件 | 说明 |
|---------|------|------|
| Spring AI SDK | `demo/invoke/SpringAiAiInvoke.java` | 通过 ChatModel 注入直接调用 |
| DashScope SDK | `demo/invoke/SdkAiInvoke.java` | 直接使用阿里 DashScope Java SDK |
| HTTP REST | `demo/invoke/HttpAiInvoke.java` | 裸 HTTP 请求调用 API |
| LangChain4j | `demo/invoke/LangChainAiInvoke.java` | 使用 langchain4j 框架 |
| 火山引擎 | `demo/invoke/VolcengineAiInvoke.java` | 使用字节跳动豆包模型 |

---

## 四、业务应用层

### 4.1 LoveApp（恋爱心理咨询场景）

#### 应用启动器

```
LoveApp (app/LoveApp.java)
  ├── ChatClient 注册 3 个默认 Advisor：
  │     MessageChatMemoryAdvisor（多轮对话）
  │     ProfanityFilterAdvisor（违禁词过滤）
  │     TimeAdvisor（耗时统计）
  └── 注入 4 个可选 Advisor：
        loveAppRagCloudAdvisor（云知识库 RAG，无扩展）
        loveAppRagCloudAdvisorWithMultiQuery（云知识库 RAG + 多查询扩展）
        loveAppRag（本地知识库 RAG + 多查询扩展）
```

#### 提供的 4 种对话方法

| 方法 | 说明 |
|------|------|
| `doChat()` | 基础对话，走 Memory + 违禁词过滤 + 耗时统计 |
| `doChatWithReport()` | 对话 + 生成结构化的恋爱报告（标题 + 建议列表） |
| `doChatWithRag()` | 当前使用 `loveAppRag` Advisor，走本地 VectorStore + RAG |

#### 请求处理链路

```
用户消息
  │
  ▼ doChatWithRag(message, chatId)
  │
  ├── MessageChatMemoryAdvisor ─→ 从 Memory 加载历史对话
  ├── ProfanityFilterAdvisor ──→ 检测违禁词，命中则拦截
  ├── TimeAdvisor ─────────────→ 记录开始时间
  ├── loveAppRag (Advisor) ────→ RAG 检索增强
  │    │
  │    ├── QueryExpander ───────→ 多查询扩展（3 扩展 + 1 原始 = 4 查询）
  │    ├── DocumentRetriever ───→ 对每个查询执行本地向量检索
  │    ├── DocumentJoiner ──────→ 去重合并
  │    └── QueryAugmenter ──────→ 将文档注入 Prompt
  │
  ├── TimeAdvisor ─────────────→ 记录耗时
  │
  ▼
  LLM 生成回答
```

### 4.2 FootballAnalysisApp（足球数据分析场景）

#### 应用启动器

```
MyFootballDataAnalysisApp (app/MyFootballDataAnalysisApp.java)
  ├── 使用 MySQL 持久化对话历史
  ├── 窗口大小 20 条
  ├── Advisors：MessageChatMemory + myLogAdvisor
  └── System Prompt 硬编码："专业足球数据分析 AI..."

FootballAnalysisApp (app/FootballAnalysisApp.java)
  ├── 与上面类似，但 System Prompt 从模板文件动态加载
  ├── 支持动态切换用户角色（教练/球迷/记者）
  └── 提供 doChatWithDynamicPrompt() 方法
```

---

## 五、Advisor 链路详解

Advisor 的执行顺序按 `getOrder()` 排序，数值越小越早执行。以下以 `doChatWithRag()` 为例展示完整的 Advisor 链路：

```
LoveApp 默认注册的 advisors (按 order 排序):
  1. TimeAdvisor (order=0)        —— 开始计时
  2. ProfanityFilterAdvisor (order=100) —— 违禁词检查
  3. MessageChatMemoryAdvisor (order=默认)  —— 加载历史对话
  4. loveAppRag (RAG Advisor)    —— 检索增强
  │
  ▼
  LLM 调用
  │
  ▼
  TimeAdvisor ─→ 结束计时，打印耗时
```

**RAG Advisor 内部链路（RetrievalAugmentationAdvisor）**：

```
1. 提取用户 Query
2. queryExpander.expand(query)     → 4 个查询
3. documentRetriever.retrieve(q)   → 每个查询 Top-K 文档
4. documentJoiner.join(documents)   → 去重合并
5. queryAugmenter.augment()         → 文档注入 Prompt
6. 返回增强后的 Prompt 给 ChatClient
```

---

## 六、测试用例一览

| 测试类 | 测试方法 | 验证内容 |
|--------|---------|---------|
| `LoveAppTest.doChat()` | 单轮对话 | 基础对话能力 |
| `LoveAppTest.doChatWithReport()` | 结构化输出 | JSON 结构化输出（恋爱报告） |
| `LoveAppTest.FileBaseChatMemoryTest()` | 多轮记忆 | Kryo 文件持久化能否记住用户信息 |
| `LoveAppTest.ProfanityFilterTest()` | 违禁词 | 不当内容是否被拦截 |
| `LoveAppTest.doChatWithRag()` | RAG 检索 | 知识库检索增强是否生效 |

---

## 七、配置文件与依赖

**Maven 核心依赖：**
- `spring-ai-alibaba-agent-framework` 1.1.2.0
- `spring-ai-alibaba-starter-dashscope` 1.1.2.0
- `spring-ai-rag` 1.1.2
- `spring-ai-markdown-document-reader` 1.1.2
- `mybatis-plus-spring-boot3-starter` 3.5.12
- `mysql-connector-java` 8.0.28

**项目核心能力验证清单：**
- [x] 基础 AI 聊天对话（doChat）
- [x] 自定义 ChatMemory — 文件持久化
- [x] 自定义 ChatMemory — MySQL 持久化
- [x] Prompt 模板（.st 文件 + 变量渲染）
- [x] 结构化输出（JSON → Java Record）
- [x] 多轮对话（MessageChatMemoryAdvisor）
- [x] 自定义 Advisor — 违禁词过滤
- [x] 自定义 Advisor — 耗时统计
- [x] 自定义 Advisor — 日志记录
- [x] 自定义 Advisor — Re2 策略
- [x] RAG — 本地知识库
- [x] RAG — 云端知识库（DashScope）
- [x] RAG — 多查询扩展
- [x] 文档处理 — TokenTextSplitter 切分
- [x] 文处理 — 关键词/摘要元信息增强
