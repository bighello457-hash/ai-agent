package com.fxs.aiagent.tools;

import org.springframework.ai.tool.annotation.Tool;

public class TerminateTool {
    @Tool(description = """
            Terminate the interaction when the request is met OR if the assistant cannot proceed further with task.
            when you hava finished all the tasks,call this tool to end the work.
            """)
    public String doTerminate(){
        return "任务结束";
    }
}
