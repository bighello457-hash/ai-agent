package com.fxs.aiagent.demo.rag;

import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.rag.generation.augmentation.ContextualQueryAugmenter;
import org.springframework.stereotype.Component;

@Component
public class createRAGAugmentFactory {
     public static ContextualQueryAugmenter createInstance(){
         PromptTemplate promptTemplate = new PromptTemplate("""
                 你应该输出下面的内容：
                 抱歉，我只能回答恋爱相关的问题，别的没办法帮到您哦，
                 有问题可以联系编程导航客服 https://codefather.cn
                 """);
         return ContextualQueryAugmenter.builder()
                 .allowEmptyContext(false)
                 .emptyContextPromptTemplate(promptTemplate)
                 .build();
     }
}
