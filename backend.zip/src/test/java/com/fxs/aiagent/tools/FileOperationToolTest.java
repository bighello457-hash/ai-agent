package com.fxs.aiagent.tools;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class FileOperationToolTest {

    @Test
    void readFile() {
        FileOperationTool fil=new FileOperationTool();
        String s = fil.readFile("傅星顺.txt");
        System.out.println(s);
        assertNotNull(s);
    }

    @Test
    void writeFile() {
        String content="Just do it";
        String filename="傅星顺.txt";
        FileOperationTool fileOperationTool=new FileOperationTool();
        String s = fileOperationTool.writeFile(filename, content);
        assertNotNull(s);
    }
}