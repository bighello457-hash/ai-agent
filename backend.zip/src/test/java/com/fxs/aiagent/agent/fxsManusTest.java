package com.fxs.aiagent.agent;

import jakarta.annotation.Resource;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class fxsManusTest {
    @Resource
    private FxsManus fxsManuss;

    @Test
    void run(){
        String userPrompt="""
                我的另一半居住在安宁区东方学苑，请帮我找到 5 公里内合适的约会地点，
                并结合一些网络图片，制定一份详细的约会计划，以
                并以 （中文）PDF 格式输出""";
//        String userPrompt="帮我生成一份报告";
        String answer = fxsManuss.run(userPrompt);
        Assertions.assertNotNull(answer);
    }
}